# 📈 TIKR-Style Real-Time Financial Dashboard

This dashboard replicates TIKR-style fundamental data visuals and tables for Indian stocks using free data from Yahoo Finance (`yfinance`).

## 🚀 Features
- Real-time price, market cap, P/E, dividend, etc.
- Financial statements: Income, Balance Sheet, Cash Flow
- Ratios: ROE, ROA, D/E, etc.
- Charts for margins, flows, valuation, risk
- Export to CSV

## 🛠 How to Run (Locally)
```bash
pip install -r requirements.txt
streamlit run app.py
```

## 🌐 Deploy on Streamlit Cloud
1. Push code to a GitHub repo
2. Go to https://streamlit.io/cloud
3. Link repo, choose `app.py` as entrypoint

## ✅ Notes
- Uses only Yahoo Finance (no paid API key needed)
- Tested with `yfinance` for NSE symbols (e.g. ITC.NS, RELIANCE.NS)
